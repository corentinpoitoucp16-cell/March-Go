#!/usr/bin/env python3
"""
Importe un CSV de marchés dont la licence autorise la réutilisation
et produit app/src/main/assets/marches.json.

Usage:
  python scripts/import_markets.py source.csv

Colonnes acceptées (variantes courantes):
nom/name, ville/city/commune, codePostal/code_postal/postcode,
adresse/address, departement/department, jours/days, horaires/hours,
lat/latitude, lon/longitude, type, tags.

Le script ne télécharge ni ne copie une base privée.
Il sert de pipeline pour des jeux de données open data/licenciés.
"""
import csv, json, re, sys, unicodedata
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/"app/src/main/assets/marches.json"

ALIASES={
 "nom":["nom","name","marche","marché"],
 "ville":["ville","city","commune","municipalite","municipalité"],
 "codePostal":["codepostal","code_postal","postcode","cp"],
 "adresse":["adresse","address","lieu","emplacement"],
 "departement":["departement","département","department"],
 "jours":["jours","days","jour","day"],
 "horaires":["horaires","hours","horaire"],
 "lat":["lat","latitude","y"],
 "lon":["lon","longitude","lng","x"],
 "type":["type","categorie","catégorie"],
 "tags":["tags","tag","types"]
}
def key(s):
    s=unicodedata.normalize("NFD",str(s)).encode("ascii","ignore").decode().lower()
    return re.sub(r"[^a-z0-9]","",s)
def pick(row,names):
    lookup={key(k):v for k,v in row.items()}
    for n in names:
        if key(n) in lookup and str(lookup[key(n)]).strip():
            return str(lookup[key(n)]).strip()
    return ""
if len(sys.argv)!=2:
    raise SystemExit("Usage: python scripts/import_markets.py source.csv")
p=Path(sys.argv[1])
with p.open("r",encoding="utf-8-sig",newline="") as f:
    rows=list(csv.DictReader(f))
out=[]
for i,row in enumerate(rows,1):
    nom=pick(row,ALIASES["nom"])
    ville=pick(row,ALIASES["ville"])
    if not nom and not ville: continue
    tags=pick(row,ALIASES["tags"])
    tags=[x.strip() for x in re.split(r"[,;|]",tags) if x.strip()]
    try: lat=float(pick(row,ALIASES["lat"])) if pick(row,ALIASES["lat"]) else None
    except ValueError: lat=None
    try: lon=float(pick(row,ALIASES["lon"])) if pick(row,ALIASES["lon"]) else None
    except ValueError: lon=None
    obj={
      "id":f"marche-{i:05d}",
      "nom":nom or "Marché",
      "ville":ville,
      "codePostal":pick(row,ALIASES["codePostal"]),
      "adresse":pick(row,ALIASES["adresse"]),
      "departement":pick(row,ALIASES["departement"]),
      "jours":pick(row,ALIASES["jours"]),
      "horaires":pick(row,ALIASES["horaires"]),
      "lat":lat,
      "lon":lon,
      "type":pick(row,ALIASES["type"]) or "Marché",
      "tags":tags,
      "source":"Open data — voir licence du fichier importé",
      "verified":bool(lat is not None and lon is not None and ville)
    }
    out.append(obj)
OUT.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding="utf-8")
print(f"{len(out)} marchés écrits dans {OUT}")
