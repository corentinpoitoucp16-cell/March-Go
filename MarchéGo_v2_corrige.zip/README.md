# MarchéGo — version 2

Cette version corrige la recherche et prépare l'application à une vraie base nationale.

## Améliorations
- Recherche par nom, ville, code postal, adresse, département, jour et horaires.
- Recherche insensible aux accents (`Vihiers`, `vihiers`, etc.).
- Affichage de l'adresse et des horaires quand ils existent.
- Favoris basés sur un identifiant stable.
- Classement GPS par distance avec affichage en kilomètres.
- Schéma de données prêt pour une base nationale.
- Importeur CSV dans `scripts/import_markets.py`.

## Important pour la base nationale
Le fichier `marches.json` livré ici conserve uniquement les données déjà présentes dans le projet. 
Il ne copie pas la base d'un annuaire privé.

Pour ajouter des milliers de marchés, fournir un CSV issu d'une source dont la licence autorise la réutilisation, puis lancer:

    python scripts/import_markets.py source.csv

Les coordonnées peuvent ensuite être vérifiées/géocodées avec la Base Adresse Nationale / Géoplateforme.
